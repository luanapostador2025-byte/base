local bit = require("bit")
Enums = {}

Enums.DailyRewardType = {
	DAILY_REWARD_TYPE_ITEMS = 1,
	DAILY_REWARD_TYPE_PREY_REROLL = 2,
	DAILY_REWARD_TYPE_XP_BOOST = 3
}

Enums.GameStoreOfferType = {
	GAMESTORE_OFFER_TYPE_NONE = 0,
	GAMESTORE_OFFER_TYPE_MOUNT = 1,
	GAMESTORE_OFFER_TYPE_OUTFIT = 2,
	GAMESTORE_OFFER_TYPE_ITEM = 3,
	GAMESTORE_OFFER_TYPE_HIRELING = 4,
}

Enums.GameStoreCoinType = {
	GAMESTORE_COIN_TYPE = 0,
	GAMESTORE_TRANSFERABLE_COIN_TYPE = 1,
}

Enums.GameStoreState = {
	GAMESTORE_CATEGORY_NONE = 0,
	GAMESTORE_CATEGORY_NEW = 1,
	GAMESTORE_CATEGORY_SALE = 2,
	GAMESTORE_CATEGORY_TIMED = 3,
}

-- the UI icon can be found above of your character inventory/set
Enums.BlessingState = {
	UNDEFINED = -1, -- bot doesn't acquired this info yet
	NONE = 0, -- no active blessings, gray icon on client UI
	NORMAL = 1, -- normal blessings, green icon on client UI
	FULL = 2 -- full blessings, gold icon on client UI
}

Enums.MonkPassiveType = {
	MONK_PASSIVE_VIRTUE_NONE = 0,
	MONK_PASSIVE_VIRTUE_HARMONY = 1,
	MONK_PASSIVE_VIRTUE_JUSTICE = 2,
	MONK_PASSIVE_VIRTUE_SUSTAIN = 3,
}

Enums.ThingFlagAttr = {
	None = 0,
	Ground = bit.lshift(1, 0),
	GroundBorder = bit.lshift(1, 1),
	OnBottom = bit.lshift(1, 2),
	OnTop = bit.lshift(1, 3),
	Container = bit.lshift(1, 4),
	Stackable = bit.lshift(1, 5),
	ForceUse = bit.lshift(1, 6),
	MultiUse = bit.lshift(1, 7),
	Writable = bit.lshift(1, 8),
	Chargeable = bit.lshift(1, 9),
	WritableOnce = bit.lshift(1, 10),
	FluidContainer = bit.lshift(1, 11),
	Splash = bit.lshift(1, 12),
	NotWalkable = bit.lshift(1, 13),
	NotMoveable = bit.lshift(1, 14),
	BlockProjectile = bit.lshift(1, 15),
	NotPathable = bit.lshift(1, 16),
	NoMovementAnimation = bit.lshift(1, 17),
	Pickupable = bit.lshift(1, 18),
	Hangable = bit.lshift(1, 19),
	HookSouth = bit.lshift(1, 20),
	HookEast = bit.lshift(1, 21),
	Rotateable = bit.lshift(1, 22),
	Light = bit.lshift(1, 23),
	DontHide = bit.lshift(1, 24),
	Translucent = bit.lshift(1, 25),
	Displacement = bit.lshift(1, 26),
	Elevation = bit.lshift(1, 27),
	LyingCorpse = bit.lshift(1, 28),
	AnimateAlways = bit.lshift(1, 29),
	MinimapColor = bit.lshift(1, 30),
	LensHelp = bit.lshift(1, 31),
	FullGround = bit.lshift(1, 32),
	Look = bit.lshift(1, 33),
	Cloth = bit.lshift(1, 34),
	Market = bit.lshift(1, 35),
	Usable = bit.lshift(1, 36),
	Wrapable = bit.lshift(1, 37),
	Unwrapable = bit.lshift(1, 38),
	UpgradeClassification = bit.lshift(1, 39),
	WearOut = bit.lshift(1, 40),
	ClockExpire = bit.lshift(1, 41),
	Expire = bit.lshift(1, 42),
	ExpireStop = bit.lshift(1, 43),
	ChangedToExpire = bit.lshift(1, 44),
	Podium = bit.lshift(1, 45),
	TopEffect = bit.lshift(1, 46),
	DefaultAction = bit.lshift(1, 47),
}

Enums.PreyTaskDataState = {
	PREY_TASK_DATA_STATE_LOCKED = 0,
	PREY_TASK_DATA_STATE_INACTIVE = 1,
	PREY_TASK_DATA_STATE_SELECTION = 2,
	PREY_TASK_DATA_STATE_LIST_SELECTION = 3,
	PREY_TASK_DATA_STATE_ACTIVE = 4,
	PREY_TASK_DATA_STATE_COMPLETED = 5
}

Enums.AlarmType = {
	DISCONNECTED = 0,
	DAMAGE_TAKEN = 1,
	LOW_HEALTH = 2,
	PRIVATE_MESSAGE = 3,
	MONSTER_DETECTED = 4,
	MONSTER_ON_SCREEN = 5,
	PLAYER_ATTACK = 6,
	PLAYER_DETECTED = 7,
	PLAYER_ON_SCREEN = 8,
	PLAYER_STUCK = 9,
	SKULL_DETECTED = 10,
	SKULL_ON_SCREEN = 11,
	ENEMY_DETECTED = 12,
	ENEMY_ON_SCREEN = 13,
	GM_DETECTED = 14,
	LOW_CAP = 15,
	PLAYER_IDLE = 16
}

-- HUD
Enums.HorizontalAlign = {
	None = 0,
	Left = 1,
	Center = 2,
	Right = 3
}

Enums.VerticalAlign = {
	None = 0,
	Top = 1,
	Center = 2,
	Bottom = 3
}

Enums.GuildEmblem = {
	GUILDEMBLEM_NONE = 0,
	GUILDEMBLEM_ALLY = 1,
	GUILDEMBLEM_ENEMY = 2,
	GUILDEMBLEM_NEUTRAL = 3,
	GUILDEMBLEM_MEMBER = 4,
	GUILDEMBLEM_OTHER = 5
}

Enums.WaypointType = {
	WAYPOINT_TYPE_STAND = 0,
	WAYPOINT_TYPE_NODE = 1,
	WAYPOINT_TYPE_START_LURE = 2,
	WAYPOINT_TYPE_END_LURE = 3,
	WAYPOINT_TYPE_ROPE = 4,
	WAYPOINT_TYPE_LADDER = 5,
	WAYPOINT_TYPE_HOLE = 6,
	WAYPOINT_TYPE_USE = 7,
	WAYPOINT_TYPE_TELEPORT = 8,
	WAYPOINT_TYPE_LABEL = 9,
	WAYPOINT_TYPE_GOTO = 10,
	WAYPOINT_TYPE_SCRIPT = 11,
	WAYPOINT_TYPE_DYNAMIC_START_LURE = 12,
	WAYPOINT_TYPE_DYNAMIC_END_LURE = 13,
	WAYPOINT_TYPE_DOOR = 14,
	WAYPOINT_TYPE_HUR_UP = 15,
	WAYPOINT_TYPE_HUR_DOWN = 16,
	WAYPOINT_TYPE_MACHETE = 17
}

Enums.SpecialAreaType = {
	SPECIAL_AREA_ALL = 0,
	SPECIAL_AREA_CAVEBOT = 1,
	SPECIAL_AREA_TARGETING = 2
}

Enums.WalkMode = {
	MAP_CLICK = 0,
	ARROW_KEYS = 1
}

Enums.PartyIcons = {
	SHIELD_NONE = 0,
	SHIELD_WHITEYELLOW = 1,
	SHIELD_WHITEBLUE = 2,
	SHIELD_BLUE = 3,
	SHIELD_YELLOW = 4,
	SHIELD_BLUE_SHAREDEXP = 5,
	SHIELD_YELLOW_SHAREDEXP = 6,
	SHIELD_BLUE_NOSHAREDEXP_BLINK = 7,
	SHIELD_YELLOW_NOSHAREDEXP_BLINK = 8,
	SHIELD_BLUE_NOSHAREDEXP = 9,
	SHIELD_YELLOW_NOSHAREDEXP = 10,
	SHIELD_GRAY = 11
}

Enums.Vocations = {
	NONE = 0,
	KNIGHT = 1,
	PALADIN = 2,
	SORCERER = 3,
	DRUID = 4,
	MONK = 5, -- 15.00+
	MASTER_SORCERER = 6,
	ELDER_DRUID = 7,
	ROYAL_PALADIN = 8,
	ELITE_KNIGHT = 9,
	EXALTED_MONK = 15 -- 15.00+
}

Enums.Directions = {
	NORTH = 0,
	EAST = 1,
	SOUTH = 2,
	WEST = 3,

	DIAGONAL_MASK = 4, -- from TFS
	SOUTHWEST = 0,
	SOUTHEAST = 0,
	NORTHWEST = 0,
	NORTHEAST = 0,
	INVALIDDIRECTION = 8
}

Enums.Directions.SOUTHWEST = bit.bor(Enums.Directions.DIAGONAL_MASK, 0)
Enums.Directions.SOUTHEAST = bit.bor(Enums.Directions.DIAGONAL_MASK, 1)
Enums.Directions.NORTHWEST = bit.bor(Enums.Directions.DIAGONAL_MASK, 2)
Enums.Directions.NORTHEAST = bit.bor(Enums.Directions.DIAGONAL_MASK, 3)

Enums.Skulls = {
	SKULL_NONE = 0,
	SKULL_YELLOW = 1,
	SKULL_GREEN = 2,
	SKULL_WHITE = 3,
	SKULL_RED = 4,
	SKULL_BLACK = 5,
	SKULL_ORANGE = 6
}

Enums.SpellGroups = {
	SPELLGROUP_NONE = 0,
	SPELLGROUP_ATTACK = 1,
	SPELLGROUP_HEALING = 2,
	SPELLGROUP_SUPPORT = 3,
	SPELLGROUP_POWERSTRIKES = 4,
	SPELLGROUP_CONJURE = 5,
	SPELLGROUP_CRIPPLING = 6,
	SPELLGROUP_FOCUS = 7,
	SPELLGROUP_ULTIMATESTRIKES = 8,
	SPELLGROUP_GREATBEAMS = 9,
	SPELLGROUP_BURSTS_OF_NATURE = 10,
	SPELLGROUP_STANCE = 11,
}

-- scripts retro-compatibility alias
Enums.SpellGroups.SPELLGROUP_SPECIAL = Enums.SpellGroups.SPELLGROUP_POWERSTRIKES
Enums.SpellGroups.SPELLGROUP_BURSTS = Enums.SpellGroups.SPELLGROUP_BURSTS_OF_NATURE
Enums.SpellGroups.SPELLGROUP_VIRTUE = Enums.SpellGroups.SPELLGROUP_STANCE

-- incomplete list
Enums.TalkTypes = {
	TALKTYPE_SAY = 1,
	TALKTYPE_WHISPER = 2,
	TALKTYPE_YELL = 3,
	TALKTYPE_PRIVATE_PN = 12 -- talk to NPC
}

Enums.MessageTypes = {
	MESSAGE_STATUS_CONSOLE_RED = 13,

	MESSAGE_STATUS_DEFAULT = 17,
	MESSAGE_STATUS_WARNING = 18,
	MESSAGE_EVENT_ADVANCE = 19,

	MESSAGE_STATUS_SMALL = 21,
	MESSAGE_INFO_DESCR = 22,
	MESSAGE_DAMAGE_DEALT = 23,
	MESSAGE_DAMAGE_RECEIVED = 24,
	MESSAGE_HEALED = 25,
	MESSAGE_EXPERIENCE = 26,
	MESSAGE_DAMAGE_OTHERS = 27,
	MESSAGE_HEALED_OTHERS = 28,
	MESSAGE_EXPERIENCE_OTHERS = 29,
	MESSAGE_EVENT_DEFAULT = 30,
	MESSAGE_LOOT = 31,

	MESSAGE_GUILD = 33,
	MESSAGE_PARTY_MANAGEMENT = 34,
	MESSAGE_PARTY = 35,
	MESSAGE_EVENT_ORANGE = 36,
	MESSAGE_STATUS_CONSOLE_ORANGE = 37,
	MESSAGE_REPORT = 38,
	MESSAGE_HOTKEY = 39,
	MESSAGE_TUTORIAL_HINT = 40,
	MESSAGE_THANK_YOU = 41,
	MESSAGE_MARKET = 42,
	MESSAGE_MANA = 43,
	MESSAGE_BEYOND_LAST = 44,

	MESSAGE_ATTENTION = 48,
	MESSAGE_BOOSTED_CREATURE = 49,
	MESSAGE_OFFLINE_TRAINING = 50,
	MESSAGE_TRANSACTION = 51,
	MESSAGE_POTION = 52
}

Enums.CreatureTypes = {
	CREATURETYPE_PLAYER = 0,
	CREATURETYPE_MONSTER = 1,
	CREATURETYPE_NPC = 2,
	CREATURETYPE_SUMMONPLAYER = 3,
	CREATURETYPE_SUMMON_OWN = 3,
	CREATURETYPE_SUMMON_OTHERS = 4,
	CREATURETYPE_HIDDEN = 5,
}

Enums.CreatureIconType = {
	QUEST = 0, -- Enums.CreatureQuestIcons
	MODIFIER = 1, -- Enums.CreatureIcons
}

Enums.CreatureIcons = {
	CREATURE_ICON_NONE = 0,
	CREATURE_ICON_HIGHER_DAMAGE_RECEIVED = 1,
	CREATURE_ICON_LOWER_DAMAGE_DEALT = 2,
	CREATURE_ICON_TURNED_MELEE = 3,
	CREATURE_ICON_INFLUENCED = 4,
	CREATURE_ICON_FIENDISH = 5,
	CREATURE_ICON_REDUCED_HEALTH = 6
}

Enums.CreatureQuestIcons = {
	CREATURE_QUEST_ICON_NONE = 0,
	CREATURE_QUEST_ICON_WHITECROSS = 1,
	CREATURE_QUEST_ICON_REDCROSS = 2,
	CREATURE_QUEST_ICON_REDBALL = 3,
	CREATURE_QUEST_ICON_GREENBALL = 4,
	CREATURE_QUEST_ICON_REDGREENBALL = 5,
	CREATURE_QUEST_ICON_GREENSHIELD = 6,
	CREATURE_QUEST_ICON_YELLOWSHIELD = 7,
	CREATURE_QUEST_ICON_BLUESHIELD = 8,
	CREATURE_QUEST_ICON_PURPLESHIELD = 9,
	CREATURE_QUEST_ICON_REDSHIELD = 10,
	CREATURE_QUEST_ICON_DOVE = 11,
	CREATURE_QUEST_ICON_ENERGY = 12,
	CREATURE_QUEST_ICON_EARTH = 13,
	CREATURE_QUEST_ICON_WATER = 14,
	CREATURE_QUEST_ICON_FIRE = 15,
	CREATURE_QUEST_ICON_ICE = 16,
	CREATURE_QUEST_ICON_ARROWUP = 17,
	CREATURE_QUEST_ICON_ARROWDOWN = 18,
	CREATURE_QUEST_ICON_EXCLAMATIONMARK = 19,
	CREATURE_QUEST_ICON_QUESTIONMARK = 20,
	CREATURE_QUEST_ICON_CANCELMARK = 21,
	CREATURE_QUEST_ICON_HAZARD = 22,
	CREATURE_QUEST_ICON_BROWNSKULL = 23,
	CREATURE_QUEST_ICON_BLOODDROP = 24
}

Enums.FlagModifiers = {
	CONTROL = 0x1,
	ALT = 0x2,
	SHIFT = 0x4,
	NUMLOCK = 0x8
}

Enums.InventorySlot = {
	CONST_SLOT_HEAD = 1,
	CONST_SLOT_NECKLACE = 2,
	CONST_SLOT_BACKPACK = 3,
	CONST_SLOT_ARMOR = 4,
	CONST_SLOT_RIGHT = 5,
	CONST_SLOT_LEFT = 6,
	CONST_SLOT_LEGS = 7,
	CONST_SLOT_FEET = 8,
	CONST_SLOT_RING = 9,
	CONST_SLOT_AMMO = 10,
	CONST_SLOT_STORE_INBOX = 11
}

Enums.States = {
	STATE_POISON = 0,
	STATE_BURN = 1,
	STATE_ENERGY = 2,
	STATE_DRUNK = 3,
	STATE_MANASHIELD = 4,
	STATE_PARALYZE = 5,
	STATE_HASTE = 6,
	STATE_SWORDS = 7,
	STATE_DROWNING = 8,
	STATE_FREEZING = 9,
	STATE_DAZZLED = 10,
	STATE_CURSED = 11,
	STATE_PARTY_BUFF = 12,
	STATE_REDSWORDS = 13,
	STATE_PIGEON = 14,
	STATE_BLEEDING = 15,
	STATE_SUFFERING_LESSER_HEX = 16,
	STATE_SUFFERING_INTENSER_HEX = 17,
	STATE_SUFFERING_GREATER_HEX = 18,
	STATE_ROOTED = 19,
	STATE_FEARED = 20,
	STATE_CURSE_I = 21,
	STATE_CURSE_II = 22,
	STATE_CURSE_III = 23,
	STATE_CURSE_IV = 24,
	STATE_CURSE_V = 25,
	STATE_MAGIC_SHIELD = 26,
	STATE_AGONY = 27
}

Enums.FightMode = {
	FIGHTMODE_ATTACK = 1,
	FIGHTMODE_BALANCED = 2,
	FIGHTMODE_DEFENSE = 3,
}

Enums.ChaseMode = {
	STAND = 0,
	CHASE = 1
}

Enums.QuestState = {
	PENDING = 0,
	COMPLETED = 1,
}